package game;

import player.Player;

public class GameEngine {

  private Player player;

  private int pillageFactor;

  private int currentTime;

  public Map map;

  public void attackVIllage(Map map) {
  }

  public Map generateMap() {
    return null;
  }

  public void getScore(Map map) {
  }

}
