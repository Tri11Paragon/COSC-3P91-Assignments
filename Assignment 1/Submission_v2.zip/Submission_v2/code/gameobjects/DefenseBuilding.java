package gameobjects;

public class DefenseBuilding extends Building {

  public int damage;

  public int range;

  public void attack(Infantry attacker) {

  }

}
