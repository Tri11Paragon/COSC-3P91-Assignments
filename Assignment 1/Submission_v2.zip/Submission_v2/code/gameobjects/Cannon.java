package gameobjects;

public class Cannon extends DefenseBuilding {
}