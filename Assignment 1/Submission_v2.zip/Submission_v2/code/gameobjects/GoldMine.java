package gameobjects;

public class GoldMine extends ResourceBuidling {

  public static String resource = "good";

}
