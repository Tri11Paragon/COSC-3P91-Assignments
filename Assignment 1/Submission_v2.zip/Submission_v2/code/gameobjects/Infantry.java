package gameobjects;

public abstract class Infantry {

  private int health;

  private int damage;

  private int range;

  public void attack(Building b) {
  }

  public void getHealth() {
  }

  public void getDamage() {
  }

  public void getRange() {
  }

}
