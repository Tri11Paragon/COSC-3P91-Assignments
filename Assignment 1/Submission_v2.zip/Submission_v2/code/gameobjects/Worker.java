package gameobjects;

public class Worker {

  private boolean currentlyBuilding;

  public boolean isCurrentlyBuilding() {
    return currentlyBuilding;
  }

}
