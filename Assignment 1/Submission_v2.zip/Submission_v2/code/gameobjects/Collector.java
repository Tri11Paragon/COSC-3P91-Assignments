package gameobjects;

import Integer;

public class Collector {

  private Integer averageCollectionRate;

  public int getCollectionRate() {
    return averageCollectionRate;
  }

}
