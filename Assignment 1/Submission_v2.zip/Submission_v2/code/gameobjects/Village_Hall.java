package gameobjects;

public class Village_Hall extends Building {

  private int goldCapacity;

  private int ironCapacity;

  private int woodCapacity;

  public int getGoldCapacity() {
  return goldCapacity;
  }

  public int getIronCapacity() {
  return ironCapacity;
  }

  public int getWoodCapacity() {
  return woodCapacity;
  }

}
