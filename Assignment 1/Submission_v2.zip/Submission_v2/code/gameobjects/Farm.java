package gameobjects;

public class Farm extends ResourceBuidling {

  public int getPopulationContribution() {
    return 0;
  }

}
