package gameobjects;

public class Catapult extends Infantry {
}