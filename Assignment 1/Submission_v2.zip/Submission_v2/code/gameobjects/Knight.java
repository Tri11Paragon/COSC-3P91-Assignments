package gameobjects;

public class Knight extends Infantry {
}