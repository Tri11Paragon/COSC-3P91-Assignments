package userinterface;

public class GuiManager {
}