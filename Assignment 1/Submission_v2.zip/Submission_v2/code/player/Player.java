package player;

public class Player {

  public int currentGold;

  public int currentIron;

  public int currentWood;

}