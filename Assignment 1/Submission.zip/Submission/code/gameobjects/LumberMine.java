package gameobjects;

public class LumberMine extends ResourceBuidling {

  public static String resource = "wood";

  public abstract void harvest(Village_Hall hall) {

  }
    
}
