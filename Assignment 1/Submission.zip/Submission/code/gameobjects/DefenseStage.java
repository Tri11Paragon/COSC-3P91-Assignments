package gameobjects;

class DefenseStage extends Stage {

  protected int dDamge;

  protected int dRange;

  public void getDamageChange() {
  }

  public void getRangeChange() {
  }

}