package gameobjects;

public class ResourceStage extends Stage {

  protected int harvestRateIncrease;

  public int getHarvestRateIncrease() {
    return harvestRateIncrease;
  }

}
