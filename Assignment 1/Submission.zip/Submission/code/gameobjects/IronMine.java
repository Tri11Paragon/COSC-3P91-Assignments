package gameobjects;

public class IronMine extends ResourceBuidling {

  public static String resource = "iron";

}
