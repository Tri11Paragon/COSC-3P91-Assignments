package gameobjects;

public class ArcherTower extends DefenseBuilding {
}