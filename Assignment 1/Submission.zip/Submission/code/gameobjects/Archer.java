package gameobjects;

public class Archer extends Infantry {
}