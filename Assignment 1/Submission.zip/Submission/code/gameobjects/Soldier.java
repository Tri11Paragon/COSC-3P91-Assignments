package gameobjects;

public class Soldier extends Infantry {
}