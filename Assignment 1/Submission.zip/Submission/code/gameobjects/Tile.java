package gameobjects;

import java.util.List;

public class Tile {

  public int x;

  public int y;

  public List<Building> building;

}
